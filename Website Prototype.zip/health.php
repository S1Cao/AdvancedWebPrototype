<html lang="en">
  <header>
    <title>Health</title>
    <?php include 'header.php';?>
  </header>
  
   <?php include 'sideBar.php';?>
  
  <footer>
    <?php include 'footer.php';?>
  </footer>
</html>