<?php
echo "This web page has been developed as a student assignment for the uINT1059 - Advanced Web. Created by ZhuoFu & Siyuan.";
?>
