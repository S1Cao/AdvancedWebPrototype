<?php
$hashed_password = password_hash($password, PASSWORD_DEFAULT);
?>